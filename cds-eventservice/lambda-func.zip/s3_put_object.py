from base64 import b64decode
from boto3 import resource, client
from datetime import datetime
from io import BytesIO
from os import environ
from time import time
from gzip import compress

s3 = client('s3')

def s3_put_object(event, context):
    event_byte_IO = BytesIO()
    event_byte_lines = []
    now = datetime.now()
    key_name = (
        "event-storage/" + environ["stage"] + '/'
        + now.strftime('%Y/%m/%d') + '/'
        + str(round(time() * 1000)) + now.strftime('-%H-%M-%S') + '.gz'
    )

    for record in event["Records"]:
        event_byte_lines.append(
            b64decode(record["kinesis"]["data"]) + bytes('\n', 'utf-8')
        )

    event_byte_IO.writelines(event_byte_lines)
    event_bytes = compress(event_byte_IO.getvalue())

    s3.put_object(Body=event_bytes, Bucket=environ["bucket"], Key=key_name)
